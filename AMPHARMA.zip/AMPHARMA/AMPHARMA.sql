/* Lógico_2: */

CREATE TABLE endereco (
    endereco_id INT PRIMARY KEY UNIQUE AUTO_INCREMENT,
    endereco_rua VARCHAR(100),
    endereco_bairro VARCHAR(100),
    endereco_cep VARCHAR(10),
    endereco_complemento VARCHAR(50),
    endereco_numero VARCHAR(10),
    endereco_descricao VARCHAR(200),
    endereco_cidade VARCHAR(100),
    endereco_uf CHAR(2),
    fk_usuarios_usuarios_id INT
);

CREATE TABLE usuarios (
    usuarios_id INT PRIMARY KEY AUTO_INCREMENT,
    usuarios_nome VARCHAR(200),
    usuarios_sexo VARCHAR(15),
    usuarios_email VARCHAR(200),
    usuarios_telefone VARCHAR(100),
    usuarios_cpf VARCHAR(15),
    usuarios_is_admin TINYINT,
    usuarios_ativo TINYINT,
    usuarios_password_hash VARCHAR(255),
    usuarios_password_confirm VARCHAR(255),
    usuarios_token VARCHAR(255),
    usuarios_expira TIMESTAMP,
    usuarios_criado_em TIMESTAMP,
    usuarios_atualizado_em TIMESTAMP,
    usuarios_deletado_em TIMESTAMP
);

CREATE TABLE pedidos (
    pedidos_id INT PRIMARY KEY AUTO_INCREMENT,
    pedidos_codigo INT,
    pedidos_situacao TINYINT,
    pedidos_valor_produto DECIMAL(9,2),
    pedidos_valor_entrega DECIMAL(9,2),
    pedidos_valor_final DECIMAL(9,2),
    pedidos_criado_em TIMESTAMP,
    pedidos_atualizado_em TIMESTAMP,
    fk_usuarios_usuarios_id INT,
    fk_produtos_produtos_id INT
);

CREATE TABLE produtos (
    produtos_id INT PRIMARY KEY AUTO_INCREMENT,
    produtos_nome VARCHAR(255),
    produtos_principio_ativo VARCHAR(255),
    produtos_descricao VARCHAR(255),
    produtos_exige_receita BOOLEAN,
    produtos_ativo TINYINT,
    produtos_categorias_id INT,
    fk_variacao_produto_variacao_produto_id INT
);

CREATE TABLE categorias (
    categorias_id INT PRIMARY KEY AUTO_INCREMENT,
    categorias_nome VARCHAR(200),
    categorias_slug VARCHAR(200),
    categorias_ativo TINYINT,
    categorias_criado_em TIMESTAMP,
    categorias_atualizado_em TIMESTAMP,
    categorias_deletado_em TIMESTAMP
);

CREATE TABLE variacao_produto (
    variacao_produto_id INT PRIMARY KEY AUTO_INCREMENT,
    variacao_produto_dosagem VARCHAR(200),
    variacao_produto_sabor VARCHAR(200),
    variacao_produto_preco DECIMAL(9,2),
    variacao_produto_qtd_estoque INT,
    variacao_produto_imagem VARCHAR(255)
);

CREATE TABLE pagamentos (
    pagamentos_id INT PRIMARY KEY AUTO_INCREMENT,
    pagamentos_forma VARCHAR(100),
    pagamentos_gateway VARCHAR(255),
    pagamentos_transacao_id VARCHAR(255),
    pagamentos_status VARCHAR(255),
    pagamentos_criado_em TIMESTAMP,
    fk_pedidos_pedidos_id INT
);
 
ALTER TABLE endereco ADD CONSTRAINT FK_endereco_2
    FOREIGN KEY (fk_usuarios_usuarios_id)
    REFERENCES usuarios (usuarios_id);
 
ALTER TABLE pedidos ADD CONSTRAINT FK_pedidos_2
    FOREIGN KEY (fk_usuarios_usuarios_id)
    REFERENCES usuarios (usuarios_id);
 
ALTER TABLE pedidos ADD CONSTRAINT FK_pedidos_3
    FOREIGN KEY (fk_produtos_produtos_id)
    REFERENCES produtos (produtos_id);
 
ALTER TABLE produtos ADD CONSTRAINT FK_produtos_2
    FOREIGN KEY (produtos_categorias_id)
    REFERENCES categorias (categorias_id);
 
ALTER TABLE produtos ADD CONSTRAINT FK_produtos_3
    FOREIGN KEY (fk_variacao_produto_variacao_produto_id)
    REFERENCES variacao_produto (variacao_produto_id);
 
ALTER TABLE pagamentos ADD CONSTRAINT FK_pagamentos_2
    FOREIGN KEY (fk_pedidos_pedidos_id)
    REFERENCES pedidos (pedidos_id);
